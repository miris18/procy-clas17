# Movimiento asincrónico de la pelota
Boiler plate para la pelota con movimiento asincrónico
